<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8e996b8fd5bf0a2688fb5c32776c03be',
      'native_key' => 'core',
      'filename' => 'modNamespace/74567dc34e4c687c4a2e985f4b9c54a2.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'af1c99c607c83d8f78b52c19613804b0',
      'native_key' => 1,
      'filename' => 'modWorkspace/97dab47b026bae18f0ea56366ddfe74b.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '999257686cd87f85c5c72418cb00ac9f',
      'native_key' => 1,
      'filename' => 'modTransportProvider/4a4dd377dc493127cf62c6edbdb8de5b.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '01ba73f113351146db510cab73934ec3',
      'native_key' => 1,
      'filename' => 'modAction/1e686c1a2226720643084fee2a28d5b2.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'b12a639edeebadddd14a955e678d1736',
      'native_key' => 3,
      'filename' => 'modAction/3c072108808367b4d6b9531893730239.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '970a1c278b81861eab53344c4c0cdd93',
      'native_key' => 5,
      'filename' => 'modAction/63c29b95f04d74f21f7431440ceff913.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1ec454e97a917246fe4a7bc6db8d3520',
      'native_key' => 7,
      'filename' => 'modAction/2ca6d51fab3d091197d3e962518bf6c8.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '16cb6d141d8c25866f2b0e9da354e6e2',
      'native_key' => 8,
      'filename' => 'modAction/630e3a6da47182d1c1d2727b79a22e25.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '076679683af7a23e28ecda23cbd5ef06',
      'native_key' => 9,
      'filename' => 'modAction/1fd8ed5787e89fcd19bbd4c5f9d971c1.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '49d78859f4c97bb960d987835df57095',
      'native_key' => 10,
      'filename' => 'modAction/1c06d2e173866b66b775bb94b94a22a5.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f46b5cbfc9e38991e6e822da98ec447b',
      'native_key' => 11,
      'filename' => 'modAction/2a855e773bebdbfe58747a48fcd4e517.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '3b02e4e8ce6d1ae63447e68d24673d4d',
      'native_key' => 12,
      'filename' => 'modAction/d55d4b41fcaf9085cfe6cd200fa8df6c.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '946885f7a15b02e76394a31192037336',
      'native_key' => 13,
      'filename' => 'modAction/5710722192860339d6e4bb8f33e47a06.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '6148017b7700b1ff00d2cd331a88ae85',
      'native_key' => 20,
      'filename' => 'modAction/6681ebe2b1279c71590a979caeddcc9d.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '6f9298feff645ba6841a197d335b46d9',
      'native_key' => 21,
      'filename' => 'modAction/72174acbf0eee1863fd78763ac244ec3.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '68c725ee4a2580529bb250b540ee189d',
      'native_key' => 22,
      'filename' => 'modAction/c2ff3f77cd71296b11dcf2bac8d2bf25.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '4395e4e058fdde4603f433bba137af2e',
      'native_key' => 25,
      'filename' => 'modAction/54344058487fa043f84f39cb9cb89786.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '308bab3d8be7da9f362b5acc1f6ea6be',
      'native_key' => 26,
      'filename' => 'modAction/22db85ec8f3fa3e6c41dd184c2fa8095.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '8130fabafb5a1c78b0fee68f45d9efae',
      'native_key' => 27,
      'filename' => 'modAction/5dee87c5006205433c6e2f3c6444f85e.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'c3f23654b209d4277221478d578a1835',
      'native_key' => 28,
      'filename' => 'modAction/6365c70d4316fbe5627cb37b6908024c.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '67fbdd4d2e4f2884581d54b6df6d50a6',
      'native_key' => 29,
      'filename' => 'modAction/f964ed82dc6351fc268c2081ed44642c.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '559fb0653a9c5d1e04621217fa953571',
      'native_key' => 30,
      'filename' => 'modAction/9a4f2afd5f5b720cd86fb910238900bf.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'a52c96e3180a15154555906bbaf2e4f0',
      'native_key' => 31,
      'filename' => 'modAction/267d58ff5ed6629d555ee25c01043cb6.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '04f9f5b9a6501ec8720049a6cfbec8a6',
      'native_key' => 32,
      'filename' => 'modAction/faa84c1568eb153d1e802d6061408121.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '4c65931377c83c8952b1a48e986d8061',
      'native_key' => 33,
      'filename' => 'modAction/f16ea69114c0d92bf08281cedfdeff91.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f3b038ca930eb820703f73f7b35e1611',
      'native_key' => 34,
      'filename' => 'modAction/3bec3aee24e63eb01f69bf2e67aef639.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '0ea88d81ce8cd26a1df3698d1a4930fa',
      'native_key' => 35,
      'filename' => 'modAction/29905bf6daf30001a898cde9675f8104.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f6244616b0a39444a60eeb0de8c6ca7f',
      'native_key' => 36,
      'filename' => 'modAction/187ca1620f89850617cefaf86ec95e02.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '990702b8ad39bb314d972f0d35c7f632',
      'native_key' => 38,
      'filename' => 'modAction/4d9cdce61dc969087c79a777c4568eb1.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'b1d7985af74225cb33586fcaa3b2f24a',
      'native_key' => 39,
      'filename' => 'modAction/08af36b2a66616d9ae5b1c5cb7bec4f4.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd667d0f24b24e1459387788f23fb36b8',
      'native_key' => 40,
      'filename' => 'modAction/4733ebcc6ac313a398b1b206b031c591.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'da68d80dcf7e4de28cedf5b80019030e',
      'native_key' => 41,
      'filename' => 'modAction/c575aeaba3fcd438e14efa1990a62cb0.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '75fc3f62f45a01fe77b35e6c573131a6',
      'native_key' => 43,
      'filename' => 'modAction/8012d4a319f80812a7a61da37ee40769.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'c20579007c6d2e54c346516d1ca3fa3c',
      'native_key' => 46,
      'filename' => 'modAction/44a9e95dbbc06bcc3574aff88585e7dc.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '52612e39b20b5893fc8dc909904de9e0',
      'native_key' => 50,
      'filename' => 'modAction/3ecedab411ec903b9e8a2b7bbc29a7b7.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '4fa35460bcb9933a8693c2bd5438dc2c',
      'native_key' => 54,
      'filename' => 'modAction/25908c1ef978144e51403b0eae6c276a.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '91f81cc8c3db16eff9aa0d0266e7ea1c',
      'native_key' => 55,
      'filename' => 'modAction/8552fe3b18761f8bca6efbd1c621adba.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '9d1958b93759a325d3a8830e8ffc4af4',
      'native_key' => 56,
      'filename' => 'modAction/eaa800744d8fdddca4d9d785d8bfc3d6.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '5f4c6f9fcac1cbef631b744df16a8bd5',
      'native_key' => 62,
      'filename' => 'modAction/19810505fc6274d79c584c190f02103d.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ee52568d075d66524ab92fa77657f847',
      'native_key' => 64,
      'filename' => 'modAction/992188118d51d8bea658ac44a78dde17.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'a5f6e34d18efca5fa79e0e6f7b0d165c',
      'native_key' => 67,
      'filename' => 'modAction/3126c0ca7db3df97548db729932f40fe.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '78794dc1daddfd26f3d7def15ea343c9',
      'native_key' => 70,
      'filename' => 'modAction/4d7956f2cad50883bf5e1503a4c9245e.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'add84068bab53d39795f3dcbabca6043',
      'native_key' => 71,
      'filename' => 'modAction/65a88d91fdba8530c069cc77d3c59f60.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '6e9f641ab0a28dd72fc797dbc3e2394a',
      'native_key' => 75,
      'filename' => 'modAction/c02164ad56d9b685dd9567dc3019fef5.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'af63cd90c0a881be981fa5fc41e75639',
      'native_key' => 82,
      'filename' => 'modAction/4ff1e59a72f5223e7fd6ac06408aeaa4.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '36798379472db133943382743713ba40',
      'native_key' => 83,
      'filename' => 'modAction/b84aebc83a9952ae3dd29f1743654542.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '4e9509627b8ed7f617ddf5ba12e34e70',
      'native_key' => 84,
      'filename' => 'modAction/10fe10ad7c74ea097ebd0f926648055b.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '0762ca0713dbeb44e75c486fb77ffda4',
      'native_key' => 85,
      'filename' => 'modAction/897ed944200689718d3cfcbfd34c5351.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '2d38d650479000d8b748a9dfa40b2c8b',
      'native_key' => 101,
      'filename' => 'modAction/bb1802da678f3551e4a282d00053f89e.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7c54012b1f7c3e53823e70018fd6497d',
      'native_key' => 102,
      'filename' => 'modAction/06faf1a715db586a5f3dfe57518c581b.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '3e934300593558a32f82625f32b7bd48',
      'native_key' => 103,
      'filename' => 'modAction/7e781bd7a081cfad47801a960569a530.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ba719cd3a5aadd32d56eb66702c2f996',
      'native_key' => 104,
      'filename' => 'modAction/5fbc56415cae4bbba07c5640cfdabfda.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f8c548925f72f5e03fdc601f40845953',
      'native_key' => 105,
      'filename' => 'modAction/776fd2297bdd454dafac66f95894aeba.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd264db99414dd8a39cbaaddc229d96fa',
      'native_key' => 106,
      'filename' => 'modAction/da309a79f4c3cd52e1a65abb2abd3859.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'c1fc2cdcf3bb6416f84273410ac5d2ed',
      'native_key' => 107,
      'filename' => 'modAction/a9bd895d19e1adb0f8a47b58e1d79c01.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7afa88587da20751ae8bc4d3c8590a7c',
      'native_key' => 'dashboard',
      'filename' => 'modMenu/fba82a8046c0fc9bdce1814f2d1c554c.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c7f7c6ff22ed1708f22b53542fa113c9',
      'native_key' => 'site',
      'filename' => 'modMenu/3d5198334c17a42fc265faaf6a8bc1d6.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '415100c787084ea13b452db0861e9b1a',
      'native_key' => 'components',
      'filename' => 'modMenu/96cabb104ab162c4d6dba3c2b8dabd38.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '120377ac64d265158f87f1f6367c2c68',
      'native_key' => 'security',
      'filename' => 'modMenu/66d1d2dae1556f3b156b6e830dfb7085.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b2b9efa115d3d6539960d419c05bea3f',
      'native_key' => 'tools',
      'filename' => 'modMenu/684960f15f1cf340d4a888301bebdff9.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a028acb1fbd302247df4e9f5952f0100',
      'native_key' => 'reports',
      'filename' => 'modMenu/2c2dffa93ccedbe7ae23ded8793e89c3.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f49cf51a909677f57385398e3db6b639',
      'native_key' => 'system',
      'filename' => 'modMenu/e3756ac2b08eb49a8ceb234d4df0564a.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c6e1de5698d66a47985f0684bbd86fa7',
      'native_key' => 'user',
      'filename' => 'modMenu/0212cb606c9ca6072f46d5c029c5d546.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4f1bdd15b6ed419c89b11c5cababbe2a',
      'native_key' => 'support',
      'filename' => 'modMenu/eb4d2ad076f0844dec515d2adcf3d91f.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '1068c6f7fd82fb475adc33c77129eec4',
      'native_key' => 1,
      'filename' => 'modContentType/1d93576803284c1d76e253eca8e417f6.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'ed1d468bfac615c33660546bfc060ca3',
      'native_key' => 2,
      'filename' => 'modContentType/77548d4de37397985a6f290b017a578a.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '6ed225d26b503cd35b7f0a1ad0af2c79',
      'native_key' => 3,
      'filename' => 'modContentType/8d3ee9675d7c328939b921e93579f6ec.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '06e7240269b86c629029f71bda9ab4e2',
      'native_key' => 4,
      'filename' => 'modContentType/22ca005c505523950ff5e6f3c1af1a3c.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a3df3990e8ac7af4f92da8a97aad95f7',
      'native_key' => 5,
      'filename' => 'modContentType/ac35709ea55090a7580cd3ed87177b98.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '0b30edbdf305956d5416d64c229a68c7',
      'native_key' => 6,
      'filename' => 'modContentType/5e546ffbfcf859d5f7ef1637f95b3eb0.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '217dddc69c2c189817ccf245cff6dc3b',
      'native_key' => 7,
      'filename' => 'modContentType/225403063ae2aeddddec4b072d6c6b72.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'deaef4a1b6bd54cc064e2880bd32357e',
      'native_key' => NULL,
      'filename' => 'modClassMap/f5ce6c5ebe3039bb346dd3380eb6f2b5.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7e84735cf5cc6ee6d931bfd45395dbc1',
      'native_key' => NULL,
      'filename' => 'modClassMap/c2d57c42f0b7099f4b1c70f3af8c804e.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '0dafd499082d590e09ab0e575012dfc1',
      'native_key' => NULL,
      'filename' => 'modClassMap/fd0ad6fa92d2f70fdc0c4a1bfc7ddfbf.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2d54ce8c98b3112f14db8b753f9da07f',
      'native_key' => NULL,
      'filename' => 'modClassMap/0170386cdb23f64f26b84b8e446064c0.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '13b948b425a5808d75dd8d7929d4b6f6',
      'native_key' => NULL,
      'filename' => 'modClassMap/f73d554a26a6e9360548406d9b6bed5c.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9fccd1aaa0ab3c14f4aafd0c30fd8076',
      'native_key' => NULL,
      'filename' => 'modClassMap/b84d86164dd806530413d9ea43901d4b.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5f813daae10fe80f105ee7f583ff94c3',
      'native_key' => NULL,
      'filename' => 'modClassMap/fcec821f53639911e3ffa79b1661cf2e.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'feba3ee3ee6d8548ef0e5edd8da6b049',
      'native_key' => NULL,
      'filename' => 'modClassMap/dc7837b63344e52ceab3c1cf44ef78ce.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'd8d3e252e442a66a4827359bb79a0fc5',
      'native_key' => NULL,
      'filename' => 'modClassMap/7dc9cce5a98dd26abf83f58886b64692.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1b1baca2236450377399c3fa9b10907',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/3d31d065e09e050236d2617389d9bb0b.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47fb88189aa816d7ec80f41a58e788c6',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/b1bbdefbc141c710e20718fbdafb2067.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d91190d02a5698634e1a06069dedcd4',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/bc57f77cacd111aed855d447294f7748.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e76ad6febd226eab19ef10d157d62b4e',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/a8e2058ab4728b06b954f7fd0c842caf.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e94f3e865b41625cf5399e1294fa634',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/8ebaf1fd213a8a5158240605062fe9ca.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '352acd96066efcade36f2ae49a9fae09',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/26be72624faecbefbe4a50ebef88c3b9.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '263681b0e9703d4d4bc8726344f9b7a5',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/cb1d5200ec2cf00d310a28599f30ea2e.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f3ad7bfcd0402ab376491c65e8c110cd',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/673c3ddc6cdb088487d9e220335885ea.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6db5f573351be20d26288cb0c0607a7d',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/fa5451e0130c1503ccfc9eeac17ee131.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a13c22db61937ed4fd2444751e56a96',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/d41a093135680632dc12b70a60717f63.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25266bc8634e471902a0f9e14c507510',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/23b2d0c32057b0d8662d028c36442b26.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1169e479f01c402ea58b504ced5aa089',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/8cb40ca8a7f32f2fbfa24778ad93c1e4.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4cf630f6b4926fdaeec72f0159c89b26',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/71646c5c5b07a85dcac529784b29c40d.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c6f251db9f0e0c5dfdad8d6ee7059e8',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/592cb357943a0895fdd76d969a64f148.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '188f39e70840f63b15badd8abb6973ec',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/63d7862301cfc6009b60bf9a2c520ff5.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba72b503bd2640489695031ed23aa979',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/c5379bc9938145a59e2bf4b5cbaf0774.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '150b944792e777c4a8b035b02f5bf97b',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/69a186d7ce51c81fd756ee6f567a132f.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af8bf308abfbd8906ddba481e9d9f65e',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/4ef2c1130499ad937bed6d036c0670d7.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f67ea3d0b9ec137bf2bfeb7ed57b7dc3',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/b729c512db3c1532f76661d8166a07ce.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad106c5227fe6436c74aa5201f1cf39e',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/01a7a0ad368119b8949f0122508cc773.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '611a609fe01f997b3554b10413f172c6',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/0418aa07d334d33bd4c752a16fd91075.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '759f60b37ada08dd1fad33762f2a5139',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/a98881aaa9d471c76253bce15b66014b.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd96651206d5fcb11b61eee309599632',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/0d915cfb5685acb08cd95cec83094968.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6419ba3fa332e380fb1d78c4830e244e',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/814d245ac1d4027411fdb3017d3dd790.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49ccd5fa10dbb419e2c0b93f63ae9603',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/0a0ec69daa574f4c0edbcf20c2d33e2d.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d2cc3f6ef94eb9d739dc6e711f11350',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/d3335f45c77f91c7e2824668f2b03c96.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c03abd079d8dbcb04cd399237654785',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/aa3b0b007feec8ee5f8ac4a539e16d05.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '20035dbe926bfeab43c904f06c9dc916',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/ae8be810cb9c3469fd01126388a4f0ed.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '982531d16b16531d60365c1ee668546a',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/bc7316601f39b77f1f8b81ef0422aa2c.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72e265f1b1229647b99ada206f58e22b',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/355a34ab0cb7cc0231f3397aefb51c9e.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4bd3905d9604ed2ae9527a79a0cfad22',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/1f276da0c06456205babc83089826c51.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1cbecd4ed2f177f7c5cc730aef00be7',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/5cb0edea87fdde2da66b52d86f619fd3.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85b7ed65035bdb8eff1302dc4a1b608a',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/eb61d87b3061a40d212d83ad39c791e3.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0e110c479c37c2e8119fadea011befe',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/c1983b2158b902bb5e7910140d5d16f5.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d757381168befc2a4ef111e020db0af',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/8405d4d097b3f4631daaa7ddbd1de4e9.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e9fdde494c0e5c2a641af86112fab90',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/5f4829a88a255cfa59994e7ea633a8ea.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b39538cfd10c5ac5541902e5a4a6249',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/106f99a66d760f30abee338e9f581172.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ea4b487e43c7beb8220e039d872b62b',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/c90480d4bab6cac17a3b412e41a31beb.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '449e09e2fda03f73b1f5d452adef21b0',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/3012fa2bbc646826552ccd7bf6616ad9.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c661b872ac4c1b3ef1dfabf9b2706c05',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/6d6dced8c22f8f1064fec6d856653660.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7723ffae884af417445d6ebab8a517f9',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/ea8152e4428f4f774764fd14e507ab63.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9dd0a393c6e73166acdbecd2f83c012',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/d7ab7313258a0df2ab0d26b9cfd276e9.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '121158c5bb7c95c7a768b1b0abcea10b',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/0f3158a34f2a7bf44d7c20aa5c11bdd6.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c4213ba0141b67b0fd7fe6fdd88fe72',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/b5528c285a9a0cdb2d79e3d5259e13f5.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6e7ad867535f7feb7d5195213fa98b8',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/46168e7736be0d4cae65792779115392.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4936a5cdb4e071a20d14f543f2ede479',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/803576ba0b5918f22df20ce4896b0844.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4829f72115b2f8d621252b7f712433e',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/cbe0c52cb7afce435e43af2bb4ecc2e5.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2913f5de49efaaf931cae9c74d749991',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/000cccf7f8ea3f56dcb42efa757ffd4c.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4b1b7838f7fedb0e2d53420518cfb8b',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/cf457662874b5f1eab976cb1190afec1.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b8bef0f524a2200154ad0539aa912ac',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/4707725dbe6c60501b6b796fd8add120.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c17526eff53714edb2f6c699d0e52d4',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/6a848589a78acc62bc1ccf7b1b465c15.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed6403a14084d1b750423a0e40668487',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/8ebf852ce8e183a785f7ac8ed2901fe0.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bbb97df50305c7415d240313d067c935',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/d76620726608a4711ca508d1133dae7a.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d489a2859111ec3a525597bd802f5f2',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/0fd7550474ff5597d975393d07dc7a15.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e715cbd1769466e3218e6e01740e86b1',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/ab2a7cec98109eb6fc01fc1173a42a47.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa1ed2d24b992531ef967478ddb9ff6f',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/6b3e7084471895c97174570a8cb041e1.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9b9f19e95bea080b5b5bbe77336f4ad',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/a69e763cacbe3139f7b1a345fb1b7529.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31a4f00c2df4a0b29cff82b9987453f3',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/b138a5cc009cd697d9a2dfbb64a19e71.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25efcf2597b0ba44310a1da8a59331cb',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/b2aedfbcaaebe581559463c55349cb60.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2a933e0978072be50182f5381f2eb4e',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/40b51d6ac55c41ba289a90ffaa28fbc1.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba0830bdaf50710b395f62c5ea88eb84',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/44b1015da9e53a22a3d060a83c162a26.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50adf225001890f726567867ac34e024',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/7cdf05d71f0f5f77d9cbdd753e8c9080.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '691fcb6b67fd7bca7909bd370203ac87',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/8d87a5f70eee83769fff3ab67adee17c.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef1068275a45ffd11b1fbc018db8ed74',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/3779870abcb1332af69f4c455c5ca554.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4691a08577676eee046827bfb47b11a9',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/969815fd9aa60e017f3ceb572e8523c6.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1fe68c6332b18a47c23e8815ff3785ca',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/703aa9c2dd48a73d1c4984a419fa6657.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64389b0acf16bc2b52899926dfc2f628',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/1b2aec8645abbcac92ed90283604d1b8.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9bce7cd50742ceb8fdac1f8091f1e249',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/278e8b37bcc793821974d1f8e55b5ac9.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5304ca3d65a721044fd46c859af2a894',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/a57128e3f440ed52a5778bd8b5fe9a66.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4293df3b3d2d3355dedf6ad8b2301c3',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/3868b35bc5d041aa60bb37cf78f4997b.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32ea5ba783fa3f80e7a5286a5bf78e17',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/739e112d57e5f2445b1a04e1b7aeed5e.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc216a7da821f8f67bb61fd2e5ed68d1',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/861ce3dd9526ddfe674c2630c08db7f4.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5030c957ff8d38c28dbd7f3ace1d9adc',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/a12415e1bf81462f0e1cb5a18502cfbc.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7dd4f5ce20fbea1b497ad2b20d39d0e2',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/0a35f92871707f685aac396c220bf1d4.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '171e33938934312c414b6033b9a26e1c',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/3c068d07cb57e9c985ffe71ae7536472.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5cbfb8cf01285457e116100ae37ecd6d',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/e6df4a560942d64f2ecb4d3e418c13dc.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e392ebab17e39e603897650f20538a6',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/4461b2d4fc4752c06ede6849f0dfc8f7.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a61997cc8c7368f47cefca34d8e90080',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/e8b0cd5ff4fb29de4bea657e5c1080f7.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58d804eb1a8db0ba08f15715ba3aba93',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/b5ba01c6f638beb2f4fc1b0644e534d2.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7999be7d225a68ca080d4bf52d483536',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/87ad6ce24ff375c97d0633ace0d7ee64.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8462782185a26c1192f11bb5848e0601',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/1ff90bbeb33475b87b221f877f80f04b.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c146cac0aed3bece95fd5174f26e049',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/5e58a5a8ab27276efd36c51ca8773c37.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dadc57a03f741daab0bfba43427e61cf',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/f4a552ac3e822dfeedaf90bcc16ce83b.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b4bc10fd5b0a35dfa1b6fb5ec695985',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/d185ba5e0872deb4b7b1f55d9ceaa16b.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '209598e98806edb748050a1068491dc5',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/4d6f6f748e91bd8915d34a63189894d8.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6364505c64a950a74b1679771caf1512',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/6974726a7386fe0c48905a88360215a3.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b1e97305f0b82df54297f83b1639ed6',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/2b4c28ae0837f76c2341160fa056d8f3.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '89c3e1cc20fe14d6052eed0493ce5fe3',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/d189d63c43393b8d897c98e6878d5e8c.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2fc4cabddb231b2e16f7abbdd1a87bf4',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/ffa16ff2390e26745c55cbc47d2a9103.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'acb4cbd66b78617b2258b63af079290b',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/16589ed76c5401e7eb5e00eae936a704.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57c5f8324e981f864403fd12429b664a',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/40b613c0bcc67251bd51aff7a769efc3.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58ddc28489018daef031801550fb3758',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/6a9a6895a6ffe4881b35cf42ed30303a.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d7ea6dcd6425e2bf29c84f4c18d13f0',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/6b791be418e34949f2337568ad13b245.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '615760910422e34dd87ec54847900a03',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/2461cda83fe28bbeb11fd84f744dbb78.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '04cedaf807932d7b67b07c2cf3bfb9d8',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/f1a2d489facaeb860159d409ee79a7e8.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d61474b2d04a84a32bb000576533caa',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/f536b40a052983458570d9b4efda9237.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '01ca00ba545e2798a1ba52d1556f6024',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/a594928c734ab2d59f3e1b71833cf4af.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3484c8842de02bf0c119646b8d6664ae',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/57ab16c38153269ef0004df332022fcb.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f097dfba94a1685402ee916c0d9f6ebc',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/7a0fb27daaeea6d094f9d3f11a0c0e3a.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41dc6dc6dbbb01ce8a4c3f57416eccbd',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/ace3915e80bfda2c6e795b1df2f48981.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b21c22cb9ea73691cf0fec1e909ef515',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/662ce829a04c2c156c5d074ae85c58ce.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8865ecdab72da57b24091a5de0e4a7b',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/5b5ef9c2486cd0acaea2a6fb2a78711b.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c463308e6e605585e9098f2a1cb0947f',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/374dc002702b6ad5ac65041ee1134c3a.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '721740972779654fee58c258c44dc66a',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/2badec28c222c1a0b663fc2b2b69ecdb.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56fcdc3ba658c843801c2ba5b405a5f1',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/83f54844d488590a183427cfdbd18123.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c595cf7dea59d481e9064746e60f701',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/9fe0136f37f776bf76aace4e84dd24cf.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28034186af3826ba8614e2613f483395',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/6f4497cf0ba5bdc6ec64c25daeefd88b.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '057fd05b9e06acea4bbe7a031139da57',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/e2de9d6db1de4f3ca6c377b41363eac6.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca4cd74fc67aacd75db6974731ad0415',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/d82495cc35b7aa71b8c7329b8422fb45.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ee2be4c517066b24fb3c8ad6c38d521',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/14290cee7d5acb950276d2eb930c6b56.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55a865daf1e5a4eecdb71a009d1a6abd',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/9bd82a3fbb09f1dc9fd198a533bb19ad.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ef47aedf6290b6fcbc5e14da6cfdb95',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/fb4df02f2f7bdc0c632c2cc77ae06187.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f8850ce33d827d6f43659b2b1657fa28',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/7ef186362a02eacb040ac46d156f081e.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7cdec67e1225f60db178fbb77b6ff78d',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/be3b71a976b9e1a84d837ea4a5644764.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8bf5a9fc2e940651f03cdca00dd1c799',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/db5cf6fed4945e96c1a778942d11c56e.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae17631d2d1aa73bbe3f52616c6378ca',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/0e24a06d2bea2de936991229be74669f.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '568f37a105b8d8b03e6342bca22725f4',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/a9658249a6f5e854a7959c2be4463cef.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22a57735446ccd988a192123781b54a6',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/ece8fdc8ce8405a7a674e4861e1ef4b5.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e57c963c10957e0f2ee875162d3d427e',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/221d18af21458f40ba3582909b288ac2.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2f9981285691aad4e28fb2767bf831f',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/b8182d102c82a39ab95f82588f166477.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36ee610f0f518df2f0bdd35d6d17f243',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/6bfa7a68cc4061ff6a121d446762ee79.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbd75697aab42b2a8da0ad7107befd6e',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/cab9209430f78a147bbd7fd1525195a8.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a3f3651e99d2968c4e58b2d8713ca525',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/bfc57be4ba39bc0252d5ecd8f41f4784.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6159dc93fbb0e86687ba77ac9f55fc6a',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/ec593c97d237f4f38003501144715486.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '042a499e61f7e0a0cb078511fb93ee9c',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/f2393b164c6b389df4c77aeb95ef8bfb.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b82ea38ad02133f1f039b3a29af7f16f',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/b0ec226f25f5e021bcdf079fc2093eaf.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c479c67f916f515c151d7461e0489d5',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/b15b7b2abaa712731bc8b44e13912d84.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '61ffa80a5d08ed9082e2f2fc081ca243',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/4fbcaad8e1a90bf6fc368c528b25bb5e.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7aabf2fd97b099ba4e6118592c374370',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/1614ea8d10a76bd8dc63f10b1f856d3b.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88a55e71b615cb3831b843de0ea941e5',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/455c9a1610beb0ea5f65109f8caa76d5.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6b7432b09c9b536d6083e03eb6341e5',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/526e238e892e5e83aafe48593b3c4f5e.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c01e469fdfbef29f4dfc23173ba7d277',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/45a8956afa43343c9794456ee5ba1184.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '663b3b583fd3e8d5a75c5919ced8202b',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/c824972f0dc59b4d832e7eaf92dd7618.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab334157976cd42f653c985d86253e28',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/4cbff2250b0ad81c544e96c1e3188d1d.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37bd760cb864a53ca6f875e64a92b222',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/e5462906adc6ad1f988972f2e33e89f4.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f3c311238f529afab3546d28d7f7f64',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/a5171dd09ec1c91a333e782d7f28bdbc.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7452ec829a83b68e4a8ab17aaee31816',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/390fd0e0afe76ec8371326ad13c674e3.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8bde3977e77579ddbeb1b5269551030e',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/0546929b2bb86be471a12bbdb00d0684.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '358efecbd9329d8ace99204d0c55c352',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/7e9d027b1ddcff34bb2de232dfc2561a.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e4653541588baacfcb105e66522d676',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/aa24dc648d0fccb491204779a9522fce.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5179176aaab413f90763bf603dff63f8',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/642bc64b3db364bdb0e7f52f72623f01.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef721e2a6b229c0f5e7ec14e734e1ad2',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/da4e5c48685bad5d7cb8b18fa9c535a0.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fd01c0771b5cfe5227f5d6c375a0a8a',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/6e1cc9542f55086e7ee7dae60e5b1d89.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '095251868d3759fad1d46631ceb3f5cc',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/0e6ad8262fe716de688ab6222033e922.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c9e7b82cf4f3c0f2695200fe4446cbc',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/9a0d29f42764d345872b30be8a5cddf0.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5afed5fd993066e4ab7208bc379e4517',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/65e7f99113b67f8527aa22d0083606f5.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb32ab1e1399f55cb71bab5574a12530',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/d19af333d04eff1df5dac20886494f93.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eaf64f50549ac77027e4f9500e8ee588',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/fce8b71081bceaa27a7921c890828d92.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4757af50006ccab3a359ff80799edb7',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/bbb30ac9b6b685cfe95c558a0113cb1f.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28b21850602c4ba312f3fffbd30b654e',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/06945aea51da146d177f49a560e729a0.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06a5e7b26d285f6976cec8c4aab8cd5a',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/d08dba3e7e2e7abbbe3a7821b55b907c.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44470bf12f0bfc89d8d3229274e85a61',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/d9ca26347986c7d1730c2b997d9a1d27.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be99d832a1ad849b69ed08d12a65d283',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/5588533e53589691f9f91667d0027166.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a34879fbb5fce6d68831da9f93bb60b',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/d46e351414012a37b24d2479304c4361.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b0695f971dde8ea6ac8f9db2b2c1c1f',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/0a6956cc74f412f5e0316c32a71140ae.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4d61ebf18fbaf5d9fd2967d12900710',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/454aca77289b35b028b6a4ea0526047a.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e1b9bf79a8ed212dd36a9b68c1d3c23',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/4a1a6a240b104e09bd9f2b35b8a0445b.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76d34ce2eec8aef03dc1ba42399c2b01',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/3c2a2dfb6fcd4f2a2ac35dd88a22de75.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5af0ed30ea99a39e8ea70bc98f3e2bcb',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/f2c978e7389c0efd0c20cfc807d66137.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0730b8bd58e28f288c9f9c44d97f0ae5',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/8f85ed3e9710e5dde56303b69ce7f0f3.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67c23ea570e8244b77ff1a6e5c3b6bd6',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/2c84d6b9982176039f731d06239bdc28.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e59893d28828922923f06d41b2fd60db',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/d1dca83ce14e0a574bcf224708382483.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa18aa42b85b03a57ba3c4567da8dde8',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/c83b2a4bedeb4da3ed6fcf4ea9f1ce81.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbf8d9756147b3c72c371e96cd89f161',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/78a5ad0be5d2d7087b7ec1a00a28725f.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e829853c56eecca6700fe9e372c7a278',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/aacdc9f49a2624cef16b39d5bdaac479.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9fd613806d964109ab32f41a7f957334',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/bbd9c13524535c451a600d3a807fa8b8.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac0fad4afe6a65b04ab6b8cd6e5f492b',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/e4d9b4fc433624682b713f815b5ef743.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3bf1a3c5789ad56b0d8b4f19281138f6',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/333d55eae1316799fe40eb79b370143b.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b4b6cf7de208ffcdd3a3048666d294a',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/41111a159ba18ea0d59a5fe59387e090.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12ebe874207b1f26545eab5e6a30b5c5',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/96b43550837b2a546fbd942f18d0c21c.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcf668780d8b73bd3c14dffd1820b23e',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/ef89823fc523d15a3fe13992e612462d.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '756f533d754ca9410e8efb07040792de',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/08abb0966b2d8ef62e9ade4111d2eb66.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48032459629b064e135a061cb2fced49',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/be5bfcb870e4c3d88a4178d9d5e6b7a2.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fa6225ac088173ee9cfe98e125b5754',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/e80763e3451d56991e7a7e7fe943a7a8.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b9fbd511c4ec0349bb958c85759b4fd',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/7f02e7cb2506c7ad5e9270693818628b.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eab802fce421ac1c51051e23c79e34e7',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/f984de3b53c8b5c3f68738aaf83e4fa7.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '591f82f1649ecf1ac87222982a5e397d',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/e123d0321eafab4c78d2aa96f00fefe4.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee3075f54a4390cffbc60b2883063816',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/c5636912108f73576b69406a1f000d0f.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fc6782236a1fabf52bf7fcf9d469849',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/f6414df124cc06c91d134800ec1151ec.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a80081ffab75cb181fe3746874df87b6',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/92613649e8889262420eaa8833339cfe.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89c62a9c9e7528c97022c85436096aa5',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/89a1af2508677955fcf8dde451063662.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67a140b7820fafb551024916180be210',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/f3d3a8a9f91a2bb634fa0864dcbcb1d0.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19b3f2ee8aba954a06b88c046f44948f',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/90ba73e6ba0936f614c261c42e49f1b1.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea7f0ccf0dedf707f1f18e02746895b8',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/9e0f53051ec45b8e077e1aa48b039eb8.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ffe0aa4702f60bee2e1d94fb4e21dbb',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/97f3d1489409d454baeed800561adaca.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa7e0d2ac0cd718171549ba8bdc59884',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/51d7f71bf5f8141faad925983cdeaf82.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b047dec22245eaddbe0d517422252cc',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/68862f7f6dcde7faf84b1c1b7c2ebb6a.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c8bd6524dff9ecc804aa67822dda6f3',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/81921f7573963c3cea29e10a4223f0de.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f768606542ba27416c23290b146f0e86',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/54cb2df5ae3d6889779a45f6f348576f.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f177211a3cd7da7233cf30d663efd6b5',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/70e6123355cb2dc5aa1c0a5047498577.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9862381f9ae04c5498ee9b6a96bfd79',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/536fd5ec42908efc29025e4db9848e71.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f771fa4b45981fbe070ccf12eb8be1cd',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/e501e3400df7b4f2a17c136483047f68.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4058a9227e1952302b61980fa2c3b700',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/fb9f3955aa17a395019e9deeb4455d0a.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17b40191f17f7eb689d8bba0c7f27a12',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/2d6a6b7df6a4d36e14afcd83033bb225.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee64868f79bccf5c32ab38c9d0f7ff99',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/eab09720f0ff7b9464b6477db4b25b5b.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d9778f15539b08e5a3f9d4e5c3a2c1d',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/d04498ae3b56cf293854ec0df0aaecaf.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab4d87193c92344b6164b3461b21f078',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/77e68dfd527fc1f0a78bbd21ae537a8e.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4702d6d00c4708f3c797adafee25002a',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/9f3da52953757e98c80c3e74d228201d.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1575b6f6e015a803eba48f6b2ce49c67',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/3e65ae741cfa1b3414e6eaf88ad8926f.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe62bff544d21052fc1d3d5b87bba8f6',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/f7f5592c037fe4bd4d0cf31e2554c6de.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e0b1993532516f3b6adc3271f7a7f77',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/e803b9874481cb38b533050743bf3d40.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f15aa1136b49ef5a8401772449ba100',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/3040f81ee24bdaff9d783f8953355be8.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a21b101436090741fab7bb8a182a4773',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/887b66b30c27433342d4a7130ae9a28b.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7b8c46b2db77eb509f4b6aac5b5f51f',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/87cbbd3e79bb9987a1a112d45c9a469a.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a68bdc807b352abefd8cf9647d1476f4',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/6aab9add6b081d5ffd0a02619c1a1799.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc9ec10077dec16b8df8d86d5f76caf2',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/ac03ae3ea080bd3360a1d817a2b82581.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c689b5b5be9cdd714ad1c23d83153b7',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/a00b2d0b0a5ad25099f48eb73b5b3699.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '492e759e28a56073be874f6ebbb2a07c',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/4d73dfc652529d415db17c0c8abb4cb8.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fd74f4b987bfda5f0836f65791dcf33',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/365ee1081e1016c78e47ce98a429b381.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3742ddc6c5c97a2b6c98430024dc34d2',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/6aa9463e3dd3883c47ac3816e030ed1f.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5226ff89dc23d3c62bf88d6778978c9',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/de4b84c8f28ac3df27b8f8917243a3c6.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89ad40fd3b8ce787b6bb78427a036032',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/44538ed5be6c830cd4f788f18f59561e.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca66df60026bb2e2150c9656b1ef0f5b',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/3b34931218d04ca00a1d081b02e38d3a.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5ea5ad4b3f3811c6ca4a352bb08c636',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/60da9516be3ea71c93916aec8d05937b.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdc16fd617ceee5c6a591674dc99a9d8',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/0d4c8df3b1cc4dcd3e2b1adf01c134fd.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d9c3c164fb6380b55ffea0ecf716292',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/5a1d869fe727e986aa3d2dd59d319a99.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '973eef4c7f6f81bbd39e797512ba6b87',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/9556835e29e4a11e8dbfaff9491c9da8.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'adeda17dd67d20c7ba88f2c4bbf86e5b',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/47e93a14a24ce0bc81f2bfbf338fa598.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '330c15a8591718f245aa06863c3420d9',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/ece3081ab3d7fb0a3700441ee79e2d49.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '577a88156c7a28881fac5d704bc37c78',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/21c07be026eed4833dab75958732e24d.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a4a6e24253d553eeb9e112759905966',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/bdcde201329699314ac45dac63b2ed71.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '923ec2f10c3a3e7b0a01afbbb63ca43c',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/45b156a8d5a380c8654c0860984ffa80.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6fb82c3e0b11281a3ad3aab08f2fd957',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/9a9d155ce3efa3dad9e3e1d2d82f92af.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42b3d8d5adb1acb876ce23a066e92b01',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/b120bf048aff9022fe1fb53a61c9dee7.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1651e3c4689f652dcaa8164ecdb92b1c',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/d90d7626fc95b47d979885f89694b523.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9a91429d8470bad08d8a96f41a444e7',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/b7e62dfe04ec2ca825550fde1832ab06.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e488b9ccaf9c404f313661e2c3cd59e',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/b37fe405d7e564a3cb7a69295d59bdd4.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cebff83d7f42d85d2d78489c3e957f35',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/83b60564418807ae55d6b94d23231a85.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '641650c9b8594767cc9870ac7d675e20',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/a104e802c95810e948b308dd42f192c8.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3aabe2ab0eec80179fc8c97258440ff',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/2f48544456da45e3691a72cf89ea14f5.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cec518efc172700cac40111d21cbd00',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/e31ccbe7b38509860817bc6111bd2bdf.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a926617459e9533a1c771a65bf593d63',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/3c3ff76265bde4201774dfc464e1d95f.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d5206e531ba62960f0318af0d76bad0',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/3aaf8e53c12c2549f401084a383a735a.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '943d9eb9d4c529d7c1f21ae5f3ec42c9',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/c3b86f19da83779902e73afd209e4ae1.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8cb87910b75254bffbc88a55b4264e1',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/7790972dc39f2e20531aa6e65383a2f3.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c09efaa03e2473d02c66ad3b0de2d125',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/e1506e25c89527883bb3f437c79090a9.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6bd6b013d99af8bbd31f0e4316b3522',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/d35365f54828b29c93af045dd6eab891.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02ec05abf8efbe223cb0565c9718663f',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/38791fedf4daff0972fbb679d5f57f70.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6953b68b64107486a2e4b3749718a5df',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/d454b4fff97e3b099fa04bd2d78aa1b6.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2398539f67a9040ed13786428f0e738',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/2968aac052aed46bf43e6f799ff22d5d.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32bfc93e8c2b9a8454f5069a3ec0e19d',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/8b97d07c40ee6b304b10a6d6d081adc1.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1a0b2aab3d5bf6bd2963b52399133da',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/132da40a36c5bc072fbf899bb6fe1435.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a95936475c62acbab5ba99d543d0a5b',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/e6ba48d8fa76b82b9a10a8af84143548.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '518d32dba6e08fc108fbfa824cc981b4',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/08af372704b829f3818a58c86bc259c5.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68aac46a53fc4a4e31ed98943e735d9f',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/b47fac6e1ea9db762b8840c020f63797.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5befa9e4b25599ea50e97e00bbfcfdc1',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/141e05738820814cad916a064448a568.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7ae2a4c614564a9eff18e51936b6df7',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/cf8603eefcd6b158a5fecbc763c68ace.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b52d5b7693d567f2751bfac128c5e27',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/73b1ffebe123ec7b53230cfa3d4b0979.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77766f91e0141300797fe1d0e7d40953',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/5c00c1794d9f91b71c34d4e5dc977452.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b9b9c3afbe17ac82827f710f6085b2f',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/55f913f713c015aaf258e3effeba822c.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '314ab905be6394b542ce3ad0bfdffa48',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/40cd4a4e795483344c026917dcded922.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '404003be477381248957597ffe2b344a',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/95eb72a5fa94a192791ee4004f29061f.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0404c7a11a835ab568476eee3f5af18',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/13459e6e8a6adfc6e8f05aa75ec4d723.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26615eceea76e0025b874df6fb3025c6',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/67f59a2c497391e264c670281013786f.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27581af682dfa833e12397f749b95a00',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/8716c949cce4aa082ce9aea078969f7b.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfde8984061e8a2d5705360f41e82772',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/3ddba3191625e2fc11cdafdee71426cf.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65c761b690a021b6d49a04fa8f76c0be',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/a0bda2db81a1047c64253800f40a5b98.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c0ea4687b057be7b9fff8d7d897ae4d',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/6a4a4c1d5d58738ee925ac907295ae1c.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c493308f7e434110fda74f0774e9ba9',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/b3efdba332311a454a8a1a419f4df532.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '895108b55438843867da69ff8b53275a',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/abde16bdf9f8efe348792853436772f5.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7e5aa65432e56af8bfe1024f72b0484',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/dff3dcc80827c3bc267c0018a405cf5a.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27c61ceb37e8deaeac18c14a69a21ee2',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/c583cedc04f3325cd4836cf19f255429.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '229a597c7325208eb117e429f96eabaf',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/0fe1031cc3ae76aa624ef0dc537262fa.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ba523a7c0b2026d24dda00cca0dc539',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/b07817e309c2153d29dbd7c241d9e780.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '195482ee89d9144c509dc01efe0b9584',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/6e434a62cd0af51be4e55d8740aa3c73.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '179a22886305d54f2fe59c85e716ad39',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/c29539e4f5ff8b03fe692ace95c7d28c.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bdba72713429e5a3101e343ca945ed8',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/8d3eb161ae19d7b880b295bf1a691b99.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e86ec441c53e9fbdb08d23252580cb3d',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/8d6687a601f73194e8af447369e7d357.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a51b886f328ab7825baa8f855a0fb8f9',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/f490f9628bef93f6615f52a935f48ae3.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '309f7377f4cdd2b3ce98aa91c69c0f3d',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/2de79cad9b67b77a4b7b442e1dc3974e.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53eee416ca4d5c1e44e464b48f1b8f79',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/e0b363ca438489cb863dc3075f9f6b24.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ca3a2d42682cad2c901c0914c70e7d7',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/03273edae243ace45342ee18e7eb205c.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc51ff73075b799d8873c0e228bd19ce',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/d1e63d0ad941b1d4ef15dfde875c63f7.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50544505137ca7d2feed6401e3a2f909',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/2e9fb1ddbc48b43d6100620be546c847.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fb2fb607e4ad1c44b9bbe78a04277cd',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/66c02249d100d502d1f4b3af62455527.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96e478918c00d390911527fda9817f7a',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/5a41130471ebefe91555cdb6232cf542.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63ed106ca3d2d582f25dd6082a36dce6',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/8d92481dc17b8f38e5e84af03926788c.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44410fa0ec11262f0a48febe1d376884',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/3dcc7f742a513181c2d0fa3a9284778a.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3324ad34bde9c6a9dbccb2c7d733158',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/6417cd97fc7c9fcb2c834913e346c8da.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce1f68ab8ab7b883ca909673cfe1a9d5',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/ad3fc3b3a0eb8d75eb5c95ef6f6053ab.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55db10df9c1674b1868e28299951e0e0',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/67b0e7a108e97ba7444c07661fa84d64.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f114df6fd79aff36b8bcd525d9c61585',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/8739c755f9140d0a226d6deea6642e89.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fb78665bc060db1cfbee41d89741a20',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/f82c4011e5b51dc264396d93ca2be214.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c76d52318f77b2f5a7bd67d677e9ac49',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/ea8e01ad3733118c17d2f6423ecbb05f.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64ae0233249af43108530e1a06c8b82c',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/33b226851161a98c11fea557188e291e.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba38fc50d1a7b913e6c3ebe1bef40250',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/e5dc9852778d33a6c8be87c8def5357c.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd70298ab0e9dd2626e9275fa7430986f',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/c150cfeab5568e608c306993db32ab06.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dceb8c8233e3dc0c1c473cf4b988a854',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/8ac86de2eb97e7682e04bc6562546c2e.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41e1e8ab45f039269bcb684b58f01de5',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/6fde7b4eee424e740f31be9f2c02a9d0.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44a2da9cddf13d218c42ec70f5933b69',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/bdcce0b4c1bd8de1797d021f937ac35f.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '588fd79cc38e86d70581dace17ccf11f',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/011ab634ee9059b09e8238a0311af0d0.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da00a24fbc5b2864ebfee8703b5ee278',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/566173f4e8dbb642e7e53a96115800b9.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f527a1c2a3550360b40965a3b92968f',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/b29e84831ab699bddd56ee5504653d6f.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c2b8e10eaccd1bf167bc190fdaa2038',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/dcef9be41abd0010d585085557c8b4f1.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '448cdb5e971b68442b4ee522079939c4',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/28618ec1cfb45a065bf9e9ef6fcbd4ff.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '159e5eb621048de62370659094ca06db',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/bb66d7ec8323099b112b95aa0c0f9340.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34019f410f996a237e27a66b9e7580c3',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/7d7729b2ea6042f3928a490de2f3b827.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8463a2f44dcfdd23202b04d5656a7887',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/b980e953fee1391ccb7cd3b518f089b4.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3c349c2178ba8af9c6ae8aa77345175',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/20521f63292e5ccdc61e302278c489fb.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54ca2d43357157c50fa8bcdd910e184b',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/429561591444c45982ce9ac32bf24e6c.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1264118f45d317ecbd82c6ff6927e582',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/c81f82c37c8f47b591d48d3f4821c60c.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4d94724c972f0de99a993ae847a60f8',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/5fc6ef3cb7fdb683f31bd4b8d18d4b5f.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4246ded2d79d4f709df590a57b25a702',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/ab8fb6f488f9a7fdfbda4a2515c86ab0.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '939a03537626fc40a5d69cf2f8977713',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/363f909e365c654390f7bf4e813c3824.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7851b0bcb79dbe2cac6dc811ec33f2ac',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/1e7c752c19d3492f1319129bbc9c224d.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '393238f6f2798ef56f142b96d9975e1d',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/fee1de499305484cddd6e13ae33d9a1b.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17bc90d20375e105668ac482c191e01b',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/350b48c671f7e0f83598c419d4a11a2b.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a709f631223a71099ae9513f58a1d782',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/3a223549a042d28013157bd90bf55062.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc94870597146870b027166df746b9ab',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/a6b930949a31ffedd609efda790e5000.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13a8e7717988b1959eb20a00fe6dd2e4',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/8a89b971d63ec4a39a0b973459ad650b.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f87600158e842f757d580a183a031b7a',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/2ce2a4fcbc43a93b5ee43d90c0a3a53a.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a7c374a130da21543cc2f6a5b3e792b',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/fbc530ebfb536b77f45bcdb62d8ff276.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8854ead58df106eef6be03eaaf2e583c',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/4d2cc476f795e073ac3478de939e68b6.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d896ff6a3cee5142b9d3c44459b41b7',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/a9a8493a182fd9f28534f2cda749ab0a.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a19fb4d2d7c164b39631bff06655abf2',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/e6bf53a896e1f0bb207b478b050686d5.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0419cc68b0358c3da4fcb5941fb38903',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/6c5a53c1e306f6e56d57800eb8c85487.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a5a4f39ecb6f8a90179edde68d649b4',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/c4feff3d7ac510095cd217fbcfdf477f.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ad593da6c49a46374977a4f1bbb8a2f',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/76a9db759d5e6640456afd9801da12d6.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26f0cfd3cfd6cffba83712ae33d40d7a',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/bb83f15537f3615d2d803a1514333aff.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71c441c05bd0fc6175b6b3893c926614',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/6f9e6e851d3cb90cdbab0924b9b1a358.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd463a73d27840ac9b2896ce90f2c2688',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/83d4d3815304719559777c2bf63f43f0.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12a977071dab430f8805e642b65b664e',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/0d3ecb1cae57e6c369636e2eeb72a280.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b579e325bf8ace017a18432420e1adb',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/ea07b3f4b9ca2d93c0bfbe4d25a51f43.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3f0208ff096e23d8fd97d991f511611',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/c5ece55867b894592bc29bb69ef6f632.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5df939a4b2ff29c31fa7ed67da7000e0',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/54d7394f62fea820304e686a42b5ca30.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da4615f1f4b97e988ad0ad30d16619de',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/08484a8fbdcdef5c503b7148acf91e58.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '768a97b28f566fbe770a68c90898bd25',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/1085442df2f173b33d48ab52ecbc68ba.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7d19291b486b4053921967b54cdd273',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/89447088359a3f20cd165ca1db2b6ce4.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '797baf1c5afeff40f04a957bd07583d3',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/8591532ebda81c12ee832380dbcee146.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30a1d5b109be4a3bedd779d13c2f0ab0',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/def572dd8a84ee5264677f3495513ab1.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef34a6fb495ce570c0389e8d7d99ef2a',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/125c667a288a3be0de54e5c930281268.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6c206728f481e8fc717b6c3b4ebbef6',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/7dc067cf065bbab6f234448d5c91904b.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fbcdd771fc98743ef77f7ee2290aa6d',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/5b8752853c7e7d6148d42ed297702ae6.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ea7082780d38a431d74a3b5ff96febd',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/84244ea262c3efac9d34ec38ac9c6df6.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '406ee90e4710662f299b2f49018a6196',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/4120e313bfbf966c1572b9c7305b99c6.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ad0518cec11cc19e4539a9dab495fcf',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/b084b482ccdaa0dae2f55bebf4031866.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1983d3ae0316077d2026189d40a63ec',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/53bbb5bf9ecaf0297995725c0021ee50.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2c987e2bdf641f197f12cf7ded64c23',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/5179b25a606a47104d0b1950c8dc04de.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04fd91303f7a83ae3cb59197934ab26b',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/b875181ee4e82906b354ce1c96ae9af5.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13899aa731fdee403af60502fa16c49e',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/bb8b20aac1d03c89acf13c1464e9dd60.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1b80b9d24499171c439d21e6e30e8a2',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/bb42a5cc06759cd2c47ac2c8665ddde1.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce2b04923adf8ea672cec04219c5fbdf',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/caf22201d380587cea3e2e84b51b339e.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c68cd0e75c2203ba2e91cf831004113',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/676372f25502602a57ea5571f5fc4a85.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a02a4cbdbfadb1b08aa33b0b751c278a',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/7ac8e1a7c4e9b4343c9cee98e7009658.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2492261377cf6a6061df8d4df0a4af90',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/be2238a33a0b527ceb3128760e1a53af.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8adcf31b5a7f3fa5d52e0b81c858d8a',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/cfca6d211e93bab21f21ec29433712be.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54ec7ff706de25f441f92a917b540b92',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/3226bb9a68fd349fd78c61129ec8a4d0.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1020c4d46b1c317a24190c18197b9de',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/4af12ceb4c1fe7df80e86a52b3eed1fe.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5bad5e0fc5e5f924f0c23b76ea23708',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/c44b9097e6cdbdef8b1c1d0755248ef8.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a98f31d92d59bd4fd6a14aa33b12e30',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/3180fcad131cd5bfbdf08132b947d6a4.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2c93f8dd2adb2ad07d9c598a3f6c126',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/a0ce64fabf76797d4d4c905008012e26.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee66d420bd0bd8fc392a29fd88dfa1be',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/9ae31db8600007821824484401aceebf.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61068febef0b4ba24426972b68915355',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/9379c08dedfcb295d9b74fb093d6aea0.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d28c0a4d4fd46395ea1c06693279c8d',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/9870e6edef6b2717fdf32ebfc58dbb07.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2eac17c0e55cebefc07979ab131317d',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/913c2b701272ab7746e961f8c6757e5a.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2841e7a25a83a3f20888a893ab3cab70',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/f53271507cd73a5d171f81c68b00c976.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3947b520cc0d37edca632ff24abb05b',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/9440ccac4118e3d922de61a3e4de3e4f.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b05b3cd59598e034a90996b74c25492b',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/1ac0d2ab89dc0a2a9b308b503b94c590.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '578de845bb1e4c77c93751907aed149d',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/598cba701d22d9f49af448e56844c73c.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e24ab4feb079688f7030d638c252638',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/097e6281d29fa3809532d2dd91d1e7c0.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8683cdc18dcd06264c3b946faf18e93',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/80d92db94f10ef66166ed29e886f72c8.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbec2e5398d054083ef1d8bc0cbfd341',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/4f50b7f0ab1eb08b9d63320d6ebf07ac.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42e90136d5490604b0ea7b4d042834db',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/a3bfaab959829fbeac67db7549910ff5.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e33fe7cc44087cc68719f2cd85ac5fd',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/1e9955f05244cf8c050382c0db8cdd21.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92732b510ebab1d244a16b0c15cec601',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/907dd78936c209f575ad621d66128913.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a2625f60d4a139b57fe3818676175f3',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/018caf048540e4e42299aaa3d749f266.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d88b0403acc98ae117ba6d2c12ce20d',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/326cbffb56cd00b3829e84d9a3a29222.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89efe6b0211482434d73160221a5a473',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/81d1dcd627648b1713f06994b8c9e10a.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc0a2babe2f0b4391165f0ce3f0115ad',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/63377d8fe8c7f6107de70df34d75f088.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '342bc35ea6584d0c0b6a145fb07fde87',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/acc2bacae91c0b6bcd1e78acec429985.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e04b29092b1ef70725af2555a536949f',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/6023ce57ec5c852dde0e975816dd3b04.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '592451ce26f1902b244c0962241656b7',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/7f2be6e0940eceda8e14e84f043c0b5a.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53d5281b8b79f9ad91e7dac40d5e4b13',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/b0878a54bed4ad00734f81f986ab2343.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41fd814863ffbb47098620b1e53b89b0',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/5a7c42e3c843b14a7de4af0313e7a745.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eed91228ab4e25c2070b1dfd35b51b5e',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/787ffa0fe746e881cba7c741a0d1e3df.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '92a4216185e8ddd0b6318e6e382432ef',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/c65fdc311cb5f3f9ff68fbf21f3feb11.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '3fdf162541746da6d24b2abe0391735d',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/90363d40e051b6ff42fd90b9b21d3dbb.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'ba18d351a78d528b075cce06931f659b',
      'native_key' => 1,
      'filename' => 'modUserGroup/6d78816734846bfe3de4ac531ec02c20.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '8b203b8bbfe10e5ff4761d454729087b',
      'native_key' => 1,
      'filename' => 'modDashboard/47f566f63b3c67e261d86dc10ea36303.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '4eef84874eb703b2baec022014c09c30',
      'native_key' => 1,
      'filename' => 'modMediaSource/5d03fc5e0b9b8ae14682a22b8e469cc3.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '72ebd1c3c6bb4039bb605b2b0cdaa885',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/c2b4e1f93fb718ce06cb4a0923195905.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '0fe0085186c824bf50d8044556edca9a',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/93891c8385acd17463ec6339c2084329.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'cdbc2beeaa1932cf11f25fc79a993579',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/ce077ded5de1a86699d98e3267a8857a.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f6d490b0b4a44c1cd76e55775b5eb567',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/2ca83f78cb3a66f7bfb910fe74014353.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '4c8b2c45287d48a839edad9c6d216922',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/7c481de101fc0bb0051fd09486144b88.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '5ccb4b0bf72293f9ebe95175c8b25f37',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/97e14ea64a304e0909fbfb2b35f9eda6.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '6a3f24c929370e9416a8310f73ed96ad',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/937f93aaee8b10d9424176f301b11e24.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'a5d850744df3b296ec797a903628c5fd',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/b5394457418c515540b480c4aa1d9288.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '695c60646bb8e4733415b121545a63c7',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/df12f0eea96af19f9cd01dca09020982.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'bf77ca3dfd0ab6300939f5858e1ef19d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/cd7d2f0b21aefb366790a01085e2b43e.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'e6af95f93404ea06685484b0fe8833e4',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/2df0c67d48f8af255593dc09b0de7b82.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '198b6f60aab3a6a9b66e91663063cbc0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/ae7391af6872aeccdc8422ebc1ca6178.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '8ba78decde3b44930ff1d83d6dcaf02a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/04bc21b56e49475ce9e1ed21b701f86f.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '90262d00c417dbbc687eb3a1a95606fc',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/058b4daa51875514c82b21e0c2b63333.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'af24d95988f9a36b8789e78f2855f36b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/236c11b081ba8361e61eb76be4d2773f.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '09dadc53ff44216f049b4b2173a20117',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/7acfe70daa6850eed69e5b92d5f6d1f7.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b904084f3cc9893bac58dfa6d898887d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/6fab2a8f398baac6cb5143850211ac63.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '936210baeb151b24cdeb8248216c9b7d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b92ef267d02818ddb72289286d88cf21.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'df4b3d6d51c0af279c54493434d6a75b',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/7e35d49c377b88e0b4da5626cc2d9ac2.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7c191c7cf525a66f5274cee30f2aa0fb',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/4c93ac72a7f30e2335c534dacff85f7a.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7e9afd7c8f563e91ff771c3f596e7e6d',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/c09d6e6688d499ef73965ac62de2d024.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '25b31d80cf84914356516e8302a961d6',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/84b8271c54b6d72d280f9e6d6c1958ad.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd01620937011916d5307ecc096638fcd',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/534fc7a2127c86b6a8486d828308fda3.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0ccb2ef8d1816ec3959253df8c9fd689',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/86c4dc38b3157b117a7af4e1a1fba17a.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f9b99e5af1e23c3c56ff80047a493e61',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/3a9db5eceac902f8f3b0ea1440848614.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'fae453d3d8f892e6bdf3494af643d85d',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/5801e2573f77103b7536309aef674a60.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3a57885ca25e06d6fb9094fc33b7aa94',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/bc46f1c61214b383f4f7a0eb4998c902.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '83298e4ce6215027114cc7cd7184a0af',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/d85a63877257a7c6b44bcaeef0fbac4d.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c88121d853aa641c133d67461e3dcce4',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/aadaaaab962fe7ce419ccdfd4e3a1134.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'f09ab2fca914595a2115b1e28de3a07f',
      'native_key' => 'web',
      'filename' => 'modContext/1addb0eebb283494c91b2e4951f5e8f3.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'ea9b8da18284c19cfd289dc97230f972',
      'native_key' => 'mgr',
      'filename' => 'modContext/5ba74f82e6e4c998bcb120dd4e1729de.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '8fdb7f09cbd242ea91c549f59de4f997',
      'native_key' => '8fdb7f09cbd242ea91c549f59de4f997',
      'filename' => 'xPDOFileVehicle/f69d2532b941b5c02baa0e91605c3cd5.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '5561a428fa629f713a8223e1c81a978a',
      'native_key' => '5561a428fa629f713a8223e1c81a978a',
      'filename' => 'xPDOFileVehicle/a435b016ed96b4917ddc369091e616a6.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '636ff9cc40316ca1e8f23561a6abee85',
      'native_key' => '636ff9cc40316ca1e8f23561a6abee85',
      'filename' => 'xPDOFileVehicle/9a9c76f3430b70ceadd9043bd8262df1.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'ea79b9f351e4c0bf0f0ab21f169ead0e',
      'native_key' => 'ea79b9f351e4c0bf0f0ab21f169ead0e',
      'filename' => 'xPDOFileVehicle/313363b666aa9bb23f88c4636950a70f.vehicle',
    ),
    495 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'edab2dce2908d87f7698bf748a8afef7',
      'native_key' => 'edab2dce2908d87f7698bf748a8afef7',
      'filename' => 'xPDOFileVehicle/2194465f580face3d0b866ea2f0bac34.vehicle',
    ),
    496 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '66c2efb5c7c27bf6a36fd77544d06360',
      'native_key' => '66c2efb5c7c27bf6a36fd77544d06360',
      'filename' => 'xPDOFileVehicle/af74986f8155921677fd773a4fed8a73.vehicle',
    ),
    497 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '245cd3d6317db4fd07709efa3d3e62ea',
      'native_key' => '245cd3d6317db4fd07709efa3d3e62ea',
      'filename' => 'xPDOFileVehicle/cfb2f4d61a1ea4694b25022283d2214f.vehicle',
    ),
    498 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c0192afbc6cadb7464df79b33b890803',
      'native_key' => 'c0192afbc6cadb7464df79b33b890803',
      'filename' => 'xPDOFileVehicle/2e18d411d989764c5b48190712d67da2.vehicle',
    ),
    499 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'fbe145070df3fc9f28f57352e9a64cb4',
      'native_key' => 'fbe145070df3fc9f28f57352e9a64cb4',
      'filename' => 'xPDOFileVehicle/98de724da88d4bcf3ed6eb3533a92e92.vehicle',
    ),
    500 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'f783f5f6891fa8d21f4d34286ec9865d',
      'native_key' => 'f783f5f6891fa8d21f4d34286ec9865d',
      'filename' => 'xPDOFileVehicle/67a957988eef48baea7898466394db83.vehicle',
    ),
    501 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '627443dbc27c035cff4fd84e331c1171',
      'native_key' => '627443dbc27c035cff4fd84e331c1171',
      'filename' => 'xPDOFileVehicle/05e4be5b3da4a54c80a3bce40584a7b5.vehicle',
    ),
  ),
);