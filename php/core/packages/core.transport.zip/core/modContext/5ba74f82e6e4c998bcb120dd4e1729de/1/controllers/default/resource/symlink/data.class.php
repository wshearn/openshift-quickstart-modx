<?php
/**
 * @package modx
 * @subpackage manager.controllers
 */
class SymlinkDataManagerController extends ResourceDataManagerController {}
